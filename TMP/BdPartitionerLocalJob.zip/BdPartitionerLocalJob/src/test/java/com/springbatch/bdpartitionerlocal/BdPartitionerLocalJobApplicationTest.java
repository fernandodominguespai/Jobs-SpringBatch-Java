package com.springbatch.bdpartitionerlocal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdPartitionerLocalJobApplicationTest {

  @Test
  void contextLoads() {
  }

}
